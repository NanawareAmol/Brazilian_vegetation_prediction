library(shiny)
library(shinydashboard)

header <- dashboardHeader(
    title = "Brazilian Forest",
    dropdownMenuOutput("msgOutput"),
    dropdownMenu(
        type = "notifications",
        notificationItem(
            text = "The International Space Station is overhead!",
            href = "",
            icon = icon("dashboard"),
            status = "success"
        )
    ),
    dropdownMenu(
        type = "tasks",
        taskItem(
            text = "The International Space Station is overhead!",
            value = 15, #------ (this is % of task completion)
            color = "red"
        ),
        taskItem(
            text = "task 2",
            value = 55,
            color = "yellow"
        ),
        taskItem(
            text = "task 3",
            value = 80,
            color = "aqua"
        )
    )
    # dropdownMenu(
    #     type = "messages",
    #     messageItem(
    #         from = "Lucy",
    #         message = "You can view the International Space Station!",
    #         href = "https://spotthestation.nasa.gov/sightings/"
    #     )
    # )
)

sidebar <- dashboardSidebar(
    sidebarMenu(    # sidebarMenu is just a container for css styling 
        sidebarSearchForm("searchID", "searchB", "Search"),
        # Create two `menuItem()`s, "Dashboard" and "Inputs"
        menuItem("Dashboard", tabName = "dashboard", icon = icon("dashboard")),
        menuItem("Detailed Analysis", tabName = "detailedAnalysis", icon = icon("bar-chart")),
        menuItem("Raw Data", tabName = "rawData", icon = icon("table"), 
                 badgeLabel = "New", badgeColor = "green"),
        sliderInput("bins", "Number of Breaks", 1, 100, 50),    # here bins is a ID
        textInput("input_id", "Search Opportunities", "12345")
    )
)
body <- dashboardBody(
    tabItems(
        tabItem(
            tabName = "dashboard",
            fluidRow(
                column(4,
                       selectInput(
                           "selectedvariable",label = "Select Case:",choices = c("ANN","Logistic")
                       )),width=2
                ),
            mainPanel(
                h2("Summary : "),
                verbatimTextOutput("Summary")
            )
                # box(title = "box 2", status = "warning",
                # "you can add body text directly like this for this box", br()
                # "2nd text"
                #     solidHeader = T, sliderInput("bins", "Number of Breaks", 1, 100, 50),    # here bins is a ID
                # textInput("input_id", "Search Opportunities", "12345"))
            )
        )
        
    )
    



ui <- dashboardPage(header, sidebar, body)

# ui <- dashboardPage(header = header,
#                     sidebar = sidebar,
#                     body = body
# )
# 
# server <- function(input, output) {}
# 
# shinyApp(ui, server)
