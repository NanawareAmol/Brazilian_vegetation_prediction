library(shiny)
library(shinydashboard)

suppressMessages(library(tidyverse))
suppressMessages(library(ggplot2))
suppressMessages(library(SDMTools))
suppressMessages(library(caret))
library(neuralnet)


server <- function(input, output) {
 
  # vals<-reactiveValues()
  # 
  # vals <- eventReactive(input$)
  
df <- read.csv("brazilian_forest_data.csv", stringsAsFactors = T)
set.seed(100) 
s <- sample(nrow(df), round(.7*nrow(df)))
train <- df[s,]
test <- df[-s,]

X_train <- train[1:9]
X_test <- test[1:9]

y_train <- train[10:length(train)]
y_test <- test[10:length(test)]
     
  Cases <- reactive({
    if (input$selectedvariable=="Logistic") {
      
      for (column in colnames(y_train)) {
        print(column)
        fm <- as.formula(paste(column, "~ (lat +	long +	alt +	temp2m + humidity + 
                         precip +	atm +	wind + m.fapar)^3"))
        fit <- glm(fm,family = "binomial",data = df)
        
        # model
        # lat *long * (p1+p2...) + (p1+p2...)^2
        # (p1+p2....)^3
        # sum(choose(9, 0:3))
        
        logit <- step(fit, direction = "backward",trace = 0)
        # print(summary(logit))
        
        #testing the logit model on the test data
        pred <- predict(logit,X_test)
        # print(table(Actual = y_test[,which(colnames(y_test)==column)], predict = pred > 0.5))
        # print(accuracy(y_test[,which(colnames(y_test)==column)], pred))
        print(summary(logit))
      }
      
    }

      
  })
  
  output$Summary<-renderPrint({
    Cases()
  })
}